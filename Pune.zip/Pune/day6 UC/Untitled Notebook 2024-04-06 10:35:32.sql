-- Databricks notebook source
use catalog dev

-- COMMAND ----------

use marsh

-- COMMAND ----------

create table dev.marsh.emp(id int, name string)select

-- COMMAND ----------

create table dev.marsh.demp(id int)

-- COMMAND ----------

GRANT CREATE on catalog dev to `account users`

-- COMMAND ----------

CREATE OR REPLACE TABLE dev.marsh.heartrate_device (device_id INT, mrn STRING, name STRING, time TIMESTAMP, heartrate DOUBLE);

INSERT INTO dev.marsh.heartrate_device VALUES
  (23, "40580129", "Nicholas Spears", "2020-02-01T00:01:58.000+0000", 54.0122153343),
  (17, "52804177", "Lynn Russell", "2020-02-01T00:02:55.000+0000", 92.5136468131),
  (37, "65300842", "Samuel Hughes", "2020-02-01T00:08:58.000+0000", 52.1354807863),
  (23, "40580129", "Nicholas Spears", "2020-02-01T00:16:51.000+0000", 54.6477014191),
  (17, "52804177", "Lynn Russell", "2020-02-01T00:18:08.000+0000", 95.033344842);
  
SELECT * FROM dev.marsh.heartrate_device

-- COMMAND ----------

CREATE OR REPLACE VIEW dev.marsh.agg_heartrate AS (
  SELECT mrn, name, MEAN(heartrate) avg_heartrate, DATE_TRUNC("DD", time) date
  FROM dev.marsh.heartrate_device
  GROUP BY mrn, name, DATE_TRUNC("DD", time)
);
SELECT * FROM dev.marsh.agg_heartrate

-- COMMAND ----------

GRANT SELECT on view dev.marsh.agg_heartrate to `account users`

-- COMMAND ----------

CREATE OR REPLACE VIEW dev.marsh.agg_heartrate AS
SELECT
  CASE WHEN
    is_account_group_member('marsh') THEN 'REDACTED'
    ELSE mrn
  END AS mrn,
  CASE WHEN
    is_account_group_member('marsh') THEN 'REDACTED'
    ELSE name
  END AS name,
  MEAN(heartrate) avg_heartrate,
  DATE_TRUNC("DD", time) date
  FROM heartrate_device
  GROUP BY mrn, name, DATE_TRUNC("DD", time)

-- COMMAND ----------

GRANT SELECT on view dev.marsh.agg_heartrate to `marsh`

-- COMMAND ----------

select * from dev.marsh.agg_heartrate

-- COMMAND ----------



-- COMMAND ----------

CREATE OR REPLACE VIEW dev.marsh.agg_heartrate AS
SELECT
  mrn,
  time,
  device_id,
  heartrate
FROM heartrate_device
WHERE
  CASE WHEN
    is_account_group_member('mmc') THEN device_id < 30
    ELSE TRUE
  END

-- COMMAND ----------

GRANT SELECT on view dev.marsh.agg_heartrate to `mmc`

-- COMMAND ----------

select * from dev.marsh.agg_heartrate

-- COMMAND ----------

CREATE OR REPLACE FUNCTION dev.marsh.mask(x STRING)
  RETURNS STRING
  RETURN CONCAT(REPEAT("*", LENGTH(x) - 2), RIGHT(x, 2)
); 
SELECT dev.marsh.mask('sensitive data') AS data

-- COMMAND ----------

CREATE OR REPLACE VIEW dev.marsh.agg_heartrate AS
SELECT
  CASE WHEN
    is_account_group_member('account users') THEN dev.marsh.mask(mrn)
    ELSE mrn
  END AS mrn,
  time,
  device_id,
  heartrate
FROM heartrate_device
WHERE
  CASE WHEN
    is_account_group_member('account users') THEN device_id < 30
    ELSE TRUE
  END

-- COMMAND ----------

GRANT SELECT on view dev.marsh.agg_heartrate to `account users`

-- COMMAND ----------

select * from dev.marsh.agg_heartrate

-- COMMAND ----------

