# Databricks notebook source
dbfs:/mnt/cloudthats3/raw_json/restaurant_details.json